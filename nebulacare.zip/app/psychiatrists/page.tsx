import React from "react";
import AllPsychiatrist from "../components/AllPsychiatrist";

export default function Psychiatrist() {
  return (
    <main>
      <AllPsychiatrist />
    </main>
  );
}
