import React from "react";
import AllMeditations from "../components/AllMeditations";

export default function Psychiatrist() {
  return (
    <main>
      <AllMeditations />
    </main>
  );
}
