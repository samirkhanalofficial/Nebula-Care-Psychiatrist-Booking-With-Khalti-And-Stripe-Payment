class TestRepository {
  constructor() {}
  test = async () => {
    // your code
  };
}
const testRepository = new TestRepository();
export { TestRepository, testRepository };
