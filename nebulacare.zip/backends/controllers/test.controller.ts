class TestController {
  constructor() {}
  test = async () => {
    // your code
  };
}
const testController = new TestController();
export { TestController, testController };
