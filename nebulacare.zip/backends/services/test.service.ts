class TestService {
  constructor() {}
  test = async () => {
    // your code
  };
}
const testService = new TestService();
export { TestService, testService };
