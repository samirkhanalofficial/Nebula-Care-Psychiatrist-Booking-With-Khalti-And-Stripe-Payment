export type questionType = {
    question: string,
    email: string
};
