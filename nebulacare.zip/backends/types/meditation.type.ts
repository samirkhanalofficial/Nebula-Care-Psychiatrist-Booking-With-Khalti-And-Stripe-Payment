export type meditationType = {
  title: string;
  link:string;
};
