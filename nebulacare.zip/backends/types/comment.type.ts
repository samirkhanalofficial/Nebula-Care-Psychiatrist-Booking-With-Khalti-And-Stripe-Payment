export type commentType = {
  comment: string;
  email: string;
};
