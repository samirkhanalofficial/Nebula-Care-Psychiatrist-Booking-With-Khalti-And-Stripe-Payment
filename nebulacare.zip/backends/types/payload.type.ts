export type payloadType = {
  id: string;
  email: string;
  loginAt: string;
  role:string;
};
