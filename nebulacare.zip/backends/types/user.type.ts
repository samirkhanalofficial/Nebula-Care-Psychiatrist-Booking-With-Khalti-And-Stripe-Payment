export type userType = {
  fullName: string;
  email: string;
  password: string;
  age: number;
  price?: string;
  nmcNumber?: string;
};
